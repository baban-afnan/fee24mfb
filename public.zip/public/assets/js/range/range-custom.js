rangeSlider(document.querySelector('#range-slider-1'));
rangeSlider(document.querySelector('#range-slider-2'), {
  value: [0, 50],
  thumbsDisabled: [true, false],
  rangeSlideDisabled: true
})
rangeSlider(document.querySelector('#range-slider-3'), {
  orientation: 'vertical'
})
rangeSlider(document.querySelector('#range-slider-4'))
rangeSlider(document.querySelector('#range-slider-5'),{
  step: 'any'
})
// rangeSlider(document.querySelector('#range-slider-6'),{
//   step: 'any'
// })
rangeSlider(document.querySelector('#range-slider-7'),{
  step: 'any'
})   