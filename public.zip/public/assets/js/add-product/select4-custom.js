(function () {
  ("use strict");
  var input = document.querySelector("input[name=basic-tags]");
  new Tagify(input);
  var input = document.querySelector("input[name=basic-tags1]");
  new Tagify(input);
})();