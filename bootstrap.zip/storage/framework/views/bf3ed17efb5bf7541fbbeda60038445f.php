<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <div class="page-body">
    <div class="container-fluid">
        <div class="page-title">
            <div class="row">
                <div class="col-sm-6 col-12">
                    <div>
                        <h2>
                            Hello, <?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name ?? 'User'); ?>!
                        </h2>
                        <p class="mb-0 text-title-gray">"Welcome back! Continue your journey."</p>
                    </div>
                </div>
        


         <!-- Start wallet_balance (inline layout) -->
<div class="row my-4 text-center align-items-center">
    <div class="col-12">
        <div class="d-flex justify-content-center align-items-center gap-3 flex-wrap">
            <!-- Wallet icon with link (Font Awesome) -->
            <a href="<?php echo e(route('wallet')); ?>" class="me-2" title="Go to Wallet">
                <i class="fas fa-wallet fs-2 text-primary"></i>
            </a>

            <!-- Wallet balance display -->
            <?php if($wallets->isNotEmpty()): ?>
                <?php
                    $wallet = $wallets->firstWhere('currency', 'NGN') ?? $wallets->first();
                    $currencySymbol = $wallet->currency === 'NGN' ? '₦' : '$';
                ?>

                <span class="fw-light fs-3 mb-0" style="transition: color 0.2s;">
                    <?php echo e($currencySymbol); ?><?php echo e(number_format($wallet->wallet_balance ?? 0, 2)); ?>

                </span>

                <span class="badge bg-<?php echo e($wallet->status === 'active' ? 'success' : 'warning'); ?>">
                    <?php echo e(ucfirst($wallet->status)); ?>

                    <?php if($wallets->count() > 1): ?>
                        (<?php echo e($wallets->count()); ?>)
                    <?php endif; ?>
                </span>
            <?php else: ?>
                <span class="fw-light fs-3 mb-0">&#8358; 0.00</span>
                <span class="badge bg-danger">No Wallet</span>
            <?php endif; ?>
        </div>
    </div>
</div>



          </div>
         <!-- Container-fluid starts-->
          <div class="container-fluid">
            <div class="row icon-main">
              <div class="col-sm-12">
                <div class="card">
                  <div class="card-header card-no-border pb-0">
                    <h3 class="m-b-0 f-w-700">Our Services</h3>
                  </div>
                  <div class="card-body">
                    <div class="row icon-lists"> 
                      <div class="col-10 col-xxl-2 col-lg-4 col-md-6 icons-item">
                        <a href="<?php echo e(route('bvn.services')); ?>" class="d-block text-center text-decoration-none">
                          <img src="../assets/images/apps/bvnlogo.png" alt="Arrow Up Service" class="mb-2" style="width:40px;height:40px;object-fit:contain;">
                          <h5 class="mt-0">BVN Services</h5>
                        </a>
                      </div>
                      <div class="col-10 col-xxl-2 col-lg-4 col-md-6 icons-item">
                         <a href="<?php echo e(route('nin.services')); ?>" class="d-block text-center text-decoration-none">
                          <img src="../assets/images/apps/nimc1.png" alt="Arrow Up Service" class="mb-2" style="width:40px;height:40px;object-fit:contain;">
                          <h5 class="mt-0">NIN Services</h5>
                        </a>
                      </div>
                      <div class="col-10 col-xxl-2 col-lg-4 col-md-6 icons-item">
                        <a href="#" class="d-block text-center text-decoration-none">
                          <img src="../assets/images/apps/identity.png" alt="Arrow Up Service" class="mb-2" style="width:40px;height:40px;object-fit:contain;">
                          <h5 class="mt-0">Verifications</h5>
                        </a>
                      </div>
                    <div class="col-10 col-xxl-2 col-lg-4 col-md-6 icons-item">
                        <a href="bvn.php" class="d-block text-center text-decoration-none">
                          <img src="../assets/images/apps/bvnlogo.png" alt="Arrow Up Service" class="mb-2" style="width:40px;height:40px;object-fit:contain;">
                          <h5 class="mt-0">VIP Services</h5>
                        </a>
                      </div>


                        <div class="col-10 col-xxl-2 col-lg-4 col-md-6 icons-item">
                        <a href="#" class="d-block text-center text-decoration-none">
                          <img src="../assets/images/apps/support.png" alt="Arrow Up Service" class="mb-2" style="width:40px;height:40px;object-fit:contain;">
                          <h5 class="mt-0">Support</h5>
                        </a>
                      </div>
                    </div>
                  </div>
               </div>
           </div>
         </div>
      </div>
        

       

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\development\fee24mfb\resources\views/dashboard.blade.php ENDPATH**/ ?>